<#
.SYNOPSIS  Updates Google Chrome via the enterprise MSI. Fast (~1-3 min).
.EXAMPLE   .\02-Update-Chrome.ps1
.EXAMPLE   .\02-Update-Chrome.ps1 -OfflinePath D:\patches   # uses *chrome*.msi from folder
#>
[CmdletBinding()]
param([string]$OfflinePath, [string]$LogDir = 'C:\Temp\HMI-Patch')
. "$PSScriptRoot\HMI-Common.ps1"

function Update-HMIChrome {
    param([string]$OfflinePath)
    Write-Host "`n=== Google Chrome ===" -ForegroundColor Cyan
    Write-Host "Current version: $(Get-ChromeVersion)"
    $msi = $null

    if ($OfflinePath) {
        $msi = Get-ChildItem $OfflinePath -Filter '*chrome*.msi' | Select-Object -First 1 -ExpandProperty FullName
        if (-not $msi) { Write-Warning "No Chrome .msi found in $OfflinePath - skipping Chrome."; return }
    }
    else {
        if (-not (Test-Internet)) { throw 'No internet access. Use -OfflinePath <folder> with a Chrome MSI.' }
        $msi = Join-Path $env:TEMP 'googlechromestandaloneenterprise64.msi'
        Invoke-WebRequest -UseBasicParsing -OutFile $msi `
            -Uri 'https://dl.google.com/dl/chrome/install/googlechromestandaloneenterprise64.msi'
    }

    if (Get-Process chrome -ErrorAction SilentlyContinue) {
        Write-Warning 'Chrome is running. Update applies now, but open windows keep the old version until Chrome is restarted.'
    }
    $p = Start-Process msiexec.exe -ArgumentList "/i `"$msi`" /qn /norestart" -Wait -PassThru
    if (-not (Test-InstallExit $p.ExitCode)) { Write-Warning "Chrome MSI exit code $($p.ExitCode)" }
    if ($p.ExitCode -eq 3010) { $global:HMIRebootNeeded = $true }
    Write-Host "New version: $(Get-ChromeVersion)"
}

if ($MyInvocation.InvocationName -ne '.') {
    Assert-Admin
    Start-HMILog $LogDir 'chrome'
    try { Update-HMIChrome -OfflinePath $OfflinePath } finally { Stop-HMILog 'chrome' }
}
