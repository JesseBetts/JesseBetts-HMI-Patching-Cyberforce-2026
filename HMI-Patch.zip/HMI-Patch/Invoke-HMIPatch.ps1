<#
.SYNOPSIS  Master script: runs the modular steps in order.
.DESCRIPTION
    Steps (in order): Status, Chrome, Windows, Finish.
    Chrome runs BEFORE Windows so the quick win is done even if you abort the long step.
    Use -Steps to run only some of them.

.EXAMPLE   .\Invoke-HMIPatch.ps1                          # everything
.EXAMPLE   .\Invoke-HMIPatch.ps1 -Steps Chrome            # just Chrome (minutes)
.EXAMPLE   .\Invoke-HMIPatch.ps1 -Steps Status,Chrome,Finish
.EXAMPLE   .\Invoke-HMIPatch.ps1 -ReportOnly              # dry run
.EXAMPLE   .\Invoke-HMIPatch.ps1 -OfflinePath D:\patches -AutoReboot
#>
[CmdletBinding()]
param(
    [ValidateSet('Status','Chrome','Windows','Finish')]
    [string[]]$Steps = @('Status','Chrome','Windows','Finish'),
    [switch]$ReportOnly,
    [switch]$SkipWindows,
    [switch]$SkipChrome,
    [switch]$AutoReboot,
    [string]$OfflinePath,
    [string]$LogDir = 'C:\Temp\HMI-Patch'
)

. "$PSScriptRoot\HMI-Common.ps1"
. "$PSScriptRoot\01-Get-HMIStatus.ps1"
. "$PSScriptRoot\02-Update-Chrome.ps1"
. "$PSScriptRoot\03-Update-Windows.ps1"
. "$PSScriptRoot\04-Finish-HMI.ps1"

Assert-Admin
Start-HMILog $LogDir 'master'
$global:HMIRebootNeeded = $false
try {
    if ($ReportOnly) { $null = Invoke-HMIStatus 'BEFORE'; Write-Host 'ReportOnly set - no changes made.' -ForegroundColor Yellow; return }

    if ($Steps -contains 'Status')  { $null = Invoke-HMIStatus 'BEFORE' }
    if ($Steps -contains 'Chrome'  -and -not $SkipChrome)  { Update-HMIChrome  -OfflinePath $OfflinePath }
    if ($Steps -contains 'Windows' -and -not $SkipWindows) { Update-HMIWindows -OfflinePath $OfflinePath }
    if ($Steps -contains 'Finish')  { Complete-HMIPatch -AutoReboot:$AutoReboot -LogDir $LogDir }
}
finally { Stop-HMILog 'master' }
