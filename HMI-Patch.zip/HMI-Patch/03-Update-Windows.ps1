<#
.SYNOPSIS  Installs Windows updates. This is the SLOW step (30-90 min) - run it on its own.
.EXAMPLE   .\03-Update-Windows.ps1                      # online, via PSWindowsUpdate
.EXAMPLE   .\03-Update-Windows.ps1 -OfflinePath D:\patches   # .msu files, name-ordered (01-ssu.msu, 02-cu.msu)
.EXAMPLE   .\03-Update-Windows.ps1 -ListOnly             # show pending updates, install nothing
#>
[CmdletBinding()]
param([string]$OfflinePath, [switch]$ListOnly, [string]$LogDir = 'C:\Temp\HMI-Patch')
. "$PSScriptRoot\HMI-Common.ps1"

function Update-HMIWindows {
    param([string]$OfflinePath, [switch]$ListOnly)
    Write-Host "`n=== Windows Server 2019 updates ===" -ForegroundColor Cyan

    if ($OfflinePath) {
        $msus = Get-ChildItem $OfflinePath -Filter *.msu | Sort-Object Name
        if (-not $msus) { Write-Warning "No .msu files found in $OfflinePath"; return }
        foreach ($m in $msus) {
            if ($ListOnly) { Write-Host "Would install $($m.Name)"; continue }
            Write-Host "Installing $($m.Name) ..."
            $p = Start-Process wusa.exe -ArgumentList "`"$($m.FullName)`" /quiet /norestart" -Wait -PassThru
            if (-not (Test-InstallExit $p.ExitCode)) { Write-Warning "$($m.Name) exit code $($p.ExitCode)" }
            if ($p.ExitCode -eq 3010) { $global:HMIRebootNeeded = $true }
        }
        return
    }

    if (-not (Test-Internet)) { throw 'No internet access. Stage patches and use -OfflinePath <folder>.' }

    if (-not (Get-Module -ListAvailable PSWindowsUpdate)) {
        Install-PackageProvider -Name NuGet -MinimumVersion 2.8.5.201 -Force | Out-Null
        Set-PSRepository -Name PSGallery -InstallationPolicy Trusted
        Install-Module PSWindowsUpdate -Force -Scope AllUsers
    }
    Import-Module PSWindowsUpdate

    $pending = Get-WindowsUpdate -MicrosoftUpdate -NotCategory 'Drivers'
    Write-Host "Pending updates: $(@($pending).Count)"
    $pending | Format-Table KB, Size, Title -AutoSize
    if ($ListOnly) { return }

    if ($pending) {
        Install-WindowsUpdate -MicrosoftUpdate -NotCategory 'Drivers' -AcceptAll -IgnoreReboot -Verbose
    }
    if (Get-WURebootStatus -Silent) { $global:HMIRebootNeeded = $true }
}

if ($MyInvocation.InvocationName -ne '.') {
    Assert-Admin
    Start-HMILog $LogDir 'windows'
    try { Update-HMIWindows -OfflinePath $OfflinePath -ListOnly:$ListOnly } finally { Stop-HMILog 'windows' }
}
