<#  Shared helpers. Dot-sourced by every other script; not meant to be run alone. #>
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
if ($null -eq $global:HMIRebootNeeded) { $global:HMIRebootNeeded = $false }

function Test-Admin {
    $id = [Security.Principal.WindowsIdentity]::GetCurrent()
    ([Security.Principal.WindowsPrincipal]$id).IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

function Assert-Admin {
    if (-not (Test-Admin)) { throw 'Run this script from an elevated (administrator) PowerShell.' }
}

function Get-OsBuild {
    $cv = Get-ItemProperty 'HKLM:\SOFTWARE\Microsoft\Windows NT\CurrentVersion'
    "{0}.{1}" -f $cv.CurrentBuildNumber, $cv.UBR
}

function Get-ChromeVersion {
    $paths = @(
        "$env:ProgramFiles\Google\Chrome\Application\chrome.exe",
        "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe"
    )
    foreach ($p in $paths) {
        if (Test-Path $p) { return (Get-Item $p).VersionInfo.ProductVersion }
    }
    return $null
}

function Test-PendingReboot {
    $keys = @(
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending',
        'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired'
    )
    foreach ($k in $keys) { if (Test-Path $k) { return $true } }
    $null -ne (Get-ItemProperty 'HKLM:\SYSTEM\CurrentControlSet\Control\Session Manager' `
        -Name PendingFileRenameOperations -ErrorAction SilentlyContinue)
}

function Test-Internet {
    try { $null = Invoke-WebRequest -Uri 'https://www.microsoft.com' -UseBasicParsing -TimeoutSec 8; $true }
    catch { $false }
}

# 0 = ok, 3010 = ok but reboot needed, 2359302 (0x240006) = already installed
function Test-InstallExit([int]$code) { $code -in 0, 3010, 2359302 }

# Starts a transcript only if one isn't already running (master script starts it once)
function Start-HMILog([string]$LogDir, [string]$Name) {
    if ($global:HMILogActive) { return }
    New-Item -ItemType Directory -Force -Path $LogDir | Out-Null
    $stamp = Get-Date -Format 'yyyyMMdd-HHmmss'
    Start-Transcript -Path (Join-Path $LogDir "$Name-$stamp.log") | Out-Null
    $global:HMILogActive = $true
    $global:HMILogOwner  = $Name
}
function Stop-HMILog([string]$Name) {
    if ($global:HMILogActive -and $global:HMILogOwner -eq $Name) {
        Stop-Transcript | Out-Null
        $global:HMILogActive = $false
    }
}
