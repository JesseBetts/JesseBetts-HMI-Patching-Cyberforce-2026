<#
.SYNOPSIS  Post-patch summary and optional reboot.
.EXAMPLE   .\04-Finish-HMI.ps1               # show result, tell you if reboot is needed
.EXAMPLE   .\04-Finish-HMI.ps1 -AutoReboot   # reboot in 60 s if needed
#>
[CmdletBinding()]
param([switch]$AutoReboot, [string]$LogDir = 'C:\Temp\HMI-Patch')
. "$PSScriptRoot\HMI-Common.ps1"

function Complete-HMIPatch {
    param([switch]$AutoReboot, [string]$LogDir = 'C:\Temp\HMI-Patch')
    $after = [pscustomobject]@{
        Build         = Get-OsBuild
        Chrome        = Get-ChromeVersion
        PendingReboot = ((Test-PendingReboot) -or $global:HMIRebootNeeded)
    }
    Write-Host "`n=== AFTER ===" -ForegroundColor Cyan
    $after | Format-List

    if ($after.PendingReboot) {
        if ($AutoReboot) {
            Write-Host 'Rebooting in 60 seconds...' -ForegroundColor Yellow
            shutdown.exe /r /t 60 /c 'HMI patching complete - restarting'
        } else {
            Write-Host 'REBOOT REQUIRED. The new build will not show (and findings will not clear) until you reboot.' -ForegroundColor Yellow
        }
    }
    Write-Host "`nLogs in $LogDir. After rebooting, run 01-Get-HMIStatus.ps1 to confirm, then rescan." -ForegroundColor Green
}

if ($MyInvocation.InvocationName -ne '.') {
    Assert-Admin
    Complete-HMIPatch -AutoReboot:$AutoReboot -LogDir $LogDir
}
