<#
.SYNOPSIS  Read-only status check (fast, ~seconds). Changes nothing.
.EXAMPLE   .\01-Get-HMIStatus.ps1
#>
[CmdletBinding()]
param([string]$LogDir = 'C:\Temp\HMI-Patch')
. "$PSScriptRoot\HMI-Common.ps1"

function Get-HMIStatus {
    [pscustomobject]@{
        OS            = (Get-CimInstance Win32_OperatingSystem).Caption
        Build         = Get-OsBuild
        Chrome        = Get-ChromeVersion
        FreeGB        = [math]::Round((Get-PSDrive C).Free / 1GB, 1)
        PendingReboot = Test-PendingReboot
    }
}

function Invoke-HMIStatus {
    param([string]$Label = 'STATUS')
    $s = Get-HMIStatus
    Write-Host "`n=== $Label ===" -ForegroundColor Cyan
    $s | Format-List
    if ($s.FreeGB -lt 10) { Write-Warning 'Less than 10 GB free on C: - cumulative updates may fail.' }
    if ($s.PendingReboot) { Write-Warning 'A reboot is already pending. Reboot first, then re-run for best results.' }
    $s
}

if ($MyInvocation.InvocationName -ne '.') {
    Assert-Admin
    Start-HMILog $LogDir 'status'
    try { $null = Invoke-HMIStatus } finally { Stop-HMILog 'status' }
}
